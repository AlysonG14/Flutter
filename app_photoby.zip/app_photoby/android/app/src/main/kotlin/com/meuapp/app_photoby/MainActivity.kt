package com.meuapp.app_photoby

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
